import pandas as pd
import json
from typing import Callable, Dict
import ast
import chardet
import xml.etree.ElementTree as ET


def add_id_column(df: pd.DataFrame, id_prefix: str) -> pd.DataFrame:
    df["ID"] = [f"{id_prefix}{i + 1}" for i in range(len(df))]
    return df


def normalize_ATC(df: pd.DataFrame, atc_column: str, method: str) -> pd.DataFrame:
    if method == "canada":
        df[atc_column] = df['THERAPEUTIC_CLASSES'].apply(
            lambda row: [entry['TC_ATC_NUMBER']
                         for entry in row if 'TC_ATC_NUMBER' in entry] if isinstance(row, list) else []
        )
    elif method == "list":

        df[atc_column] = df[atc_column].apply(
            lambda x: ast.literal_eval(x) if isinstance(
                x, str) and x.strip() else []
        )
        df = df.explode(atc_column).reset_index(drop=True)
    elif method == "first":
        df[atc_column] = df[atc_column].apply(lambda x: str(
            x).split(" ")[0].strip() if isinstance(x, str) else x)
    elif method == "remove_quotes":
        df[atc_column] = df[atc_column].apply(
            lambda x: x.replace("'", "") if isinstance(x, str) else x)
    elif method == "bulgarian":
        df[atc_column] = df[atc_column].apply(
            lambda x: (x.replace(" ", "0") if len(x) == 7 else x.replace(" ", "")) if isinstance(x, str) else x)
    else:
        raise ValueError(f"Unknown normalization method: {method}")
    return df


def detect_file_encoding(file_path):
    with open(file_path, 'rb') as f:
        result = chardet.detect(f.read())
    return result['encoding']


def csv_reader(file_name: str, **kwargs) -> pd.DataFrame:
    add_id = kwargs.pop('add_id', None)
    id_prefix = kwargs.pop('id_prefix', None)
    normalize_atc = kwargs.pop('normalize_atc', None)
    method = kwargs.pop('method_normalize', None)
    column_normalize = kwargs.pop('column_normalize', None)
    detect_encoding = kwargs.pop('detect_encoding', None)
    use_header = kwargs.pop('use_header', True)
    headers = kwargs.pop('headers', None)

    if detect_encoding:
        kwargs['encoding'] = detect_file_encoding(file_name)

    df = pd.read_csv(file_name, dtype=str, **kwargs).where(pd.notnull, None)

    if add_id:
        df = add_id_column(df, id_prefix)
    if normalize_atc:
        df = normalize_ATC(df, column_normalize, method)
    if not use_header:
        df = df.reset_index(drop=True)
        df.columns = headers

    return df


def xlsx_reader(file_name: str, **kwargs) -> pd.DataFrame:
    add_id = kwargs.pop('add_id', None)
    id_prefix = kwargs.pop('id_prefix', None)
    normalize_atc = kwargs.pop('normalize_atc', None)
    method = kwargs.pop('method_normalize', None)
    column_normalize = kwargs.pop('column_normalize', None)

    df = pd.read_excel(file_name, dtype=str, **kwargs).where(pd.notnull, None)

    if add_id:
        df = add_id_column(df, id_prefix)
    if normalize_atc:
        df = normalize_ATC(df, column_normalize, method)

    return df


def json_reader(file_name: str, **kwargs) -> pd.DataFrame:
    normalize_atc = kwargs.pop('normalize_atc', None)
    method = kwargs.pop('method_normalize', None)
    column_normalize = kwargs.pop('column_normalize', None)
    detect_encoding = kwargs.pop('detect_encoding', None)

    if detect_encoding:
        kwargs['encoding'] = detect_file_encoding(file_name)

    df = pd.read_json(file_name, **kwargs).where(pd.notnull, None)

    if normalize_atc:
        df = normalize_ATC(df, column_normalize, method)

    return df


def read_finland(file_name: str) -> pd.DataFrame:
    tree = ET.parse(file_name)
    root = tree.getroot()
    records = []
    for product in root.findall(".//Laakevalmiste"):
        record = {}
        record["id"] = product.attrib.get("id")
        for child in product:
            tag = child.tag
            if tag == "ATC-koodi":
                record["ATC-koodi"] = child.attrib.get("id")
            elif tag == "Laakemuoto":
                record["Laakemuoto"] = child.attrib.get("value")
            elif tag == "Myyntilupa":
                myyntilupa = {}
                for subchild in child:
                    myyntilupa[subchild.tag] = subchild.text
                record["Myyntilupa"] = myyntilupa
            else:
                record[tag] = child.text
        records.append(record)

    return pd.DataFrame(records)


def read_ireland(file_name: str) -> pd.DataFrame:
    tree = ET.parse(file_name)
    root = tree.getroot()
    ns = {"h": "https://assets.hpra.ie/products//xml/Human"}

    records = []
    for product in root.findall(".//h:Product", ns):
        record = {}
        for child in product:
            tag = child.tag.split("}", 1)[-1]
            # Check if this field has nested elements
            if len(child) > 0:
                values = [c.text for c in child if c.text is not None]
                record[tag] = values
            else:
                record[tag] = child.text
        records.append(record)

    return pd.DataFrame(records)


def xml_reader(file_name: str, **kwargs) -> pd.DataFrame:
    add_id = kwargs.pop('add_id', None)
    id_prefix = kwargs.pop('id_prefix', None)
    country = kwargs.pop('country', None)

    if country == "FI":
        df = read_finland(file_name)
    elif country == "IE":
        df = read_ireland(file_name)

    if add_id:
        df = add_id_column(df, id_prefix)

    return df


READERS: Dict[str, Callable[[str], pd.DataFrame]] = {
    "csv_reader": csv_reader,
    "xlsx_reader": xlsx_reader,
    "json_reader": json_reader,
    "xml_reader": xml_reader,
}


def load_config(config_path: str):
    with open(config_path, "r", encoding='utf-8') as f:
        return json.load(f)


def read_central_index(index_path: str) -> pd.DataFrame:
    df = pd.read_excel(index_path, engine="openpyxl")
    df["ID"] = [f"CAPC_{i + 1}" for i in range(len(df))]
    df.drop(columns=["Unnamed: 6"], inplace=True)

    if "ATC code" in df.columns:

        if type(df["ATC code"].iloc[0]) != list:
            def parse_atc(val):
                if pd.isnull(val):
                    return []
                try:
                    parsed = ast.literal_eval(val)
                    if isinstance(parsed, list):
                        return [str(x) for x in parsed]
                    return [str(parsed)]
                except Exception:
                    return [str(val)]
            df["ATC code"] = df["ATC code"].apply(parse_atc)

    return df


def process_files(config_path: str) -> list:
    config = load_config(config_path)
    list_dfs = []

    for entry in config:
        print(f"Processing {entry['country']}...")
        file_name = entry["file_name"]
        reader_name = entry["reader"]
        reader_params = entry.get("reader_params", {})

        reader = READERS.get(reader_name)
        if not reader:
            print(f"Unknown reader '{reader_name}' for file {file_name}")
            continue

        try:
            list_dfs.append({"country": entry["country"],
                             "df": reader(file_name, **reader_params),
                             "id_column": entry["id_column"],
                             "name_column": entry["name_column"],
                             "match_column": entry["match_column"]
                             })

        except Exception as e:
            print(f"Error processing file {file_name}: {e}")

    return list_dfs


def match_dfs(df1: pd.DataFrame, df2: pd.DataFrame, id_column: str, name_column: str,
              match_column: str) -> pd.DataFrame:
    matches = []

    atc_to_row1 = {}
    for _, row1 in df1.iterrows():
        for atc_code in row1["ATC code"]:
            atc_to_row1.setdefault(atc_code, []).append(row1)

    for _, row2 in df2.iterrows():
        code_to_match = row2[match_column]
        if isinstance(code_to_match, list):
            for code in code_to_match:
                for row1 in atc_to_row1.get(code, []):
                    matches.append({
                        "drug_code": row1["ID"],
                        "related_drug_code": row2[id_column],
                        "drug_name": row1["Generic Name"],
                        "related_drug_name": row2[name_column],
                        "matched_atc_code": code
                    })
        else:
            for row1 in atc_to_row1.get(code_to_match, []):
                matches.append({
                    "drug_code": row1["ID"],
                    "related_drug_code": row2[id_column],
                    "drug_name": row1["Generic Name"],
                    "related_drug_name": row2[name_column],
                    "matched_atc_code": code_to_match
                })

    return pd.DataFrame(matches)


if __name__ == "__main__":
    central_index = read_central_index("Data/pillcheck.xlsx")

    list_dfs = process_files("config.json")

    print("Starting to match drugs...")

    for entry in list_dfs:
        country = entry["country"]
        print(f"Matching {country}...")

        matched_df = match_dfs(central_index, entry["df"], entry["id_column"],
                               entry["name_column"], entry["match_column"])
        matched_df.to_csv(f"matched_{country}.csv", index=False)
