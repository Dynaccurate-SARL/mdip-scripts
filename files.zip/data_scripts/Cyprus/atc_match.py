import pandas as pd


DATA = "cyprus.xlsx"
ATC = "../ATCs.xlsx"
DATA_NAME_COLUMN = "Active ingredient"


def join_dfs(drugs, atcs):

    drugs[DATA_NAME_COLUMN] = drugs[DATA_NAME_COLUMN].str.lower()

    atc_mapping = atcs.groupby('ATC level name')[
        'ATC code'].apply(list).to_dict()
    drugs['ATC code'] = drugs[DATA_NAME_COLUMN].map(atc_mapping)
    drugs['ATC code'] = drugs['ATC code'].apply(
        lambda x: list(set(x)) if isinstance(x, list) else x)

    return drugs


data_df = pd.read_excel(DATA)
act_df = pd.read_excel(ATC, sheet_name="ATC index with DDDs 2025")


resulting_df = join_dfs(data_df, act_df)
output_file = "resulting_data.xlsx"
resulting_df.to_excel(output_file, index=False)
