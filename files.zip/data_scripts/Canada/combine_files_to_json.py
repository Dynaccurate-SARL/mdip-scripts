import json
import pandas as pd

DRUGS = "drug.csv"
files_and_properties = [
    {"file": "comp.csv", "property_name": "COMPANIES"},
    {"file": "form.csv", "property_name": "FORMS"},
    {"file": "ingred.csv", "property_name": "ACTIVE_INGREDIENTS"},
    {"file": "package.csv", "property_name": "PACKAGES"},
    {"file": "pharm.csv", "property_name": "PHARMACEUTICAL_STD"},
    {"file": "route.csv", "property_name": "ROUTES"},
    {"file": "schedule.csv", "property_name": "SCHEDULES"},
    {"file": "status.csv", "property_name": "STATUSES"},
    {"file": "ther.csv", "property_name": "THERAPEUTIC_CLASSES"},
]

def group_entries(file, property_name):
    grouped_data = []

    df = pd.read_csv(file, encoding='utf-8', na_values=["", "NA", "N/A"]).fillna(value="")
    if "DRUG_CODE" in df.columns:
        grouped = df.groupby("DRUG_CODE")
        for drug_id, group in grouped:
            properties = group.drop(columns=["DRUG_CODE"]).to_dict(orient='records')
            grouped_data.append({
                "DRUG_CODE": drug_id,
                property_name: properties
            })
    
    for entry in grouped_data:
        entry[property_name] = [
            {k: v for k, v in prop.items() if v != ""}
            for prop in entry[property_name]
        ]

    return grouped_data

drugs_data = pd.read_csv(DRUGS, encoding='utf-8', na_values=["", "NA", "N/A"]).fillna(value="")
data = drugs_data.to_dict(orient='records')
data = [{k: v for k, v in elem.items() if v != ""} for elem in data]
            

for file_info in files_and_properties:
    print(f"Processing file: {file_info['file']}")
    file = file_info["file"]
    property_name = file_info["property_name"]
    grouped_entries_data = group_entries(file, property_name)

    for drug in data:
        drug_code = drug.get("DRUG_CODE")
        for entry in grouped_entries_data:
            if entry["DRUG_CODE"] == drug_code:
                drug[property_name] = entry[property_name]

with open("output.json", "w", encoding="utf-8") as json_file:
    json.dump(data, json_file, ensure_ascii=False, indent=4)


