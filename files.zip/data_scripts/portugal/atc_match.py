import pandas as pd

TRANSLATOR = "../sms-substances-list-20250718030040.csv"
DATA = "portugal.xlsx"
ATC = "../ATCs.xlsx"
DATA_NAME_COLUMN = "Substância Ativa/DCI"


def join_dfs(drugs, atcs, translation_dict):

    drugs[DATA_NAME_COLUMN] = drugs[DATA_NAME_COLUMN].str.lower()

    atc_mapping = atcs.groupby('ATC level name')[
        'ATC code'].apply(list).to_dict()
    drugs['ATC code'] = drugs[DATA_NAME_COLUMN].map(translation_dict).map(atc_mapping)
    drugs['ATC code'] = drugs['ATC code'].apply(
        lambda x: list(set(x)) if isinstance(x, list) else x)

    return drugs

translator_df = pd.read_csv(TRANSLATOR, dtype=str)
translator_df = translator_df[translator_df['Language'].isin(['Portuguese', 'English'])]
translator_df_g = translator_df.groupby('#SMS_ID')

translation_dict = {}
for sms_id, group in translator_df_g:
    languages = set(group['Language'])
    if 'English' in languages and 'Portuguese' in languages:
        p = group.loc[group['Language'] == 'Portuguese', 'Substance_Name'].iat[0]
        e = group.loc[group['Language'] == 'English', 'Substance_Name'].iat[0]
        translation_dict[p.lower()] = e.lower()

print(translation_dict)

data_df = pd.read_excel(DATA)
act_df = pd.read_excel(ATC, sheet_name="ATC index with DDDs 2025")


resulting_df = join_dfs(data_df, act_df, translation_dict)
output_file = "resulting_data.xlsx"
resulting_df.to_excel(output_file, index=False)
