import json
import xml.etree.ElementTree as ET
from typing import Dict, List

VMP_FIELDS_DECODER = {
    'VPID': 'VMP ID',
    'INVALID': 'Is Invalid',
    'VTMID': 'VTM ID',
    'NM': 'Name',
    'NMDT': 'Name Date',
    'ABBREVNM': 'Abbreviated Name',
    'COMBPRODCD': 'Combination Product',                   # lookup
    'VPIDDT': 'Date',
    'VPIDPREV': 'Previous ID',
    'BASISCD': 'Basis of Name',                             # lookup
    'NMPREV': 'Previous Name',
    'BASIS_PREVCD': 'Basis of Previous Name',               # lookup
    'NMCHANGECD': 'Reason for Change Name',                 # lookup
    'PRES_STATCD': 'Prescribing Status',                    # lookup
    'SUG_F': 'Sugar Free',                                 # boolean
    'GLU_F': 'Gluten Free',                                # boolean
    'PRES_F': 'Preservative Free',                         # boolean
    'CFC_F': 'CFC Free',                                   # boolean
    'NON_AVAILCD': 'AMP Non-availability',                  # lookup
    'NON_AVAILDT': 'Non-availability Date',
    'DF_INDCD': 'Dose Form Indicator',                      # lookup
    'UDFS': 'Unit Dose Form Size',
    'UDFS_UOMCD': 'Unit Dose Form Units',                   # lookup
    'UNIT_DOSE_UOMCD': 'Unit Dose Unit of Measure'          # lookup
}

DRUG_LOOKUP_DECODER = {
    'COMBPRODCD': 'COMBINATION_PROD_IND',
    'BASISCD': 'BASIS_OF_NAME',
    'BASIS_PREVCD': 'BASIS_OF_NAME',
    'NMCHANGECD': 'NAMECHANGE_REASON',
    'PRES_STATCD': 'VIRTUAL_PRODUCT_PRES_STATUS',
    'NON_AVAILCD': 'VIRTUAL_PRODUCT_NON_AVAIL',
    'DF_INDCD': 'DF_INDICATOR',
    'UDFS_UOMCD': 'UNIT_OF_MEASURE',
    'UNIT_DOSE_UOMCD': 'UNIT_OF_MEASURE',
    'SUPPCD': 'SUPPLIER',
    'FLAVOURCD': 'FLAVOUR',
    'LIC_AUTHCD': 'LICENSING_AUTHORITY',
    'LIC_AUTH_PREVCD': 'LICENSING_AUTHORITY',
    'LIC_AUTHCHANGECD': 'LICENSING_AUTHORITY_CHANGE_REASON',
    'AVAIL_RESTRICTCD': 'AVAILABILITY_RESTRICTION'
}

BOOLEAN_FIELDS = ['INVALID', 'SUG_F', 'GLU_F', 'PRES_F', 'CFC_F', 'EMA', 'PARALLEL_IMPORT']
LOOKUP_FIELDS = ['COMBPRODCD', 'BASISCD', 'BASIS_PREVCD', 'NMCHANGECD', 'PRES_STATCD', 'NON_AVAILCD', 'DF_INDCD', 'UDFS_UOMCD',
                'UNIT_DOSE_UOMCD', 'SUPPCD', 'FLAVOURCD', 'LIC_AUTHCD', 'LIC_AUTH_PREVCD', 'LIC_AUTHCHANGECD', 'AVAIL_RESTRICTCD']

def generate_lookup(lookup_file):
    lookup_dict = dict()

    tree = ET.parse(lookup_file)
    root = tree.getroot()
    for item in root:
        lookup_dict[item.tag] = dict()
        for elem in item:
            lookup_dict[item.tag][elem.find('CD').text] = elem.find('DESC').text

    return lookup_dict


def extract_drugs(drug_file, lookup_dict, type):
    list_drug = []

    root_tag = 'VMPS'
    id_tag = 'VPID'
    decoder = VMP_FIELDS_DECODER

    tree = ET.parse(drug_file)    
    drug_root = tree.getroot().find(root_tag)

    for drug in drug_root:
        drug_dict = dict()
        drug_dict['Category'] = type
        drug_dict['Is Invalid'] = 'No'
        for attribute in drug:
            if attribute.tag == id_tag:
                drug_dict[decoder[attribute.tag]] = attribute.text
            else:
                if attribute.tag in BOOLEAN_FIELDS:
                    drug_dict[decoder[attribute.tag]] = 'Yes'
                elif attribute.tag in LOOKUP_FIELDS:
                    drug_dict[decoder[attribute.tag]] = lookup_dict[DRUG_LOOKUP_DECODER[attribute.tag]][attribute.text]
                else:
                    drug_dict[decoder[attribute.tag]] = attribute.text
        list_drug.append(drug_dict)
        
    return list_drug

def add_atcs(vmp_codes: List[Dict], atc_file) -> List[Dict]:
    result = []
    atc_tree = ET.parse(atc_file)
    atc_root = atc_tree.getroot()
    vpid_to_atc = {}
    for vmp in atc_root.find('VMPS'):
        vpid = vmp.find('VPID').text
        atc = vmp.find('ATC').text if vmp.find('ATC') is not None else None
        if atc:
            vpid_to_atc[vpid] = atc

    for vmp in vmp_codes:
        if vmp['VMP ID'] in vpid_to_atc:
            vmp['ATC'] = vpid_to_atc[vmp['VMP ID']]
        result.append(vmp)

    return result

def main(lookup_file: str, vmp_file: str, atc_file: str, output_file: str):
    lookup_dict = generate_lookup(lookup_file)
    list_vmp = extract_drugs(vmp_file, lookup_dict, 'VMP')
    list_drugs = add_atcs(list_vmp, atc_file)

    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(list_drugs, f, ensure_ascii=False, sort_keys=True, indent=2)


if __name__ == "__main__":
    lookup_file = 'f_lookup2_3030725.xml'
    vmp_file = 'f_vmp2_3030725.xml'
    atc_file = 'f_bnf1_0030725.xml'
    output_file = 'uk.json'
    main(lookup_file, vmp_file, atc_file, output_file)